package com.mygdx.game.util;

public enum UserAction {
    MOVE_LEFT,
    MOVE_RIGHT,
    MOVE_UP,
    MOVE_DOWN,
    ESCAPE,
    ENTER
}

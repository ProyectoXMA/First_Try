package com.mygdx.game.model.movement;

public interface MovementStrategy {
    public void move(Movable movable, float delta);
}
